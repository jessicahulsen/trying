<?php
/**
 * TS Charity Theme Customizer
 *
 * @package ts-charity
 */

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function ts_charity_customize_register( $wp_customize ) {	

	//add home page setting pannel
	$wp_customize->add_panel( 'ts_charity_panel_id', array(
	    'priority' => 10,
	    'capability' => 'edit_theme_options',
	    'theme_supports' => '',
	    'title' => __( 'Theme Settings', 'ts-charity' ),
	    'description' => __( 'Description of what this panel does.', 'ts-charity' ),
	) );

	//Layouts
	$wp_customize->add_section( 'ts_charity_left_right', array(
    	'title'      => __( 'Layout Settings', 'ts-charity' ),
		'priority'   => 30,
		'panel' => 'ts_charity_panel_id'
	) );

	// Add Settings and Controls for Layout
	$wp_customize->add_setting('ts_charity_layout_options',array(
	        'default' => __('Right Sidebar','ts-charity'),
	        'sanitize_callback' => 'ts_charity_sanitize_choices'	        
	)  );
	$wp_customize->add_control('ts_charity_layout_options',
	    array(
	        'type' => 'radio',
	        'label' => __('Change Layouts','ts-charity'),
	        'section' => 'ts_charity_left_right',
	        'choices' => array(
	            'Left Sidebar' => __('Left Sidebar','ts-charity'),
	            'Right Sidebar' => __('Right Sidebar','ts-charity'),
	            'One Column' => __('One Column','ts-charity'),
	            'Three Columns' => __('Three Columns','ts-charity'),
	            'Four Columns' => __('Four Columns','ts-charity'),
	            'Grid Layout' => __('Grid Layout','ts-charity')
	        ),
	) );

	$font_array = array(
        '' => __( 'No Fonts', 'ts-charity' ),
        'Abril Fatface' => __( 'Abril Fatface', 'ts-charity' ),
        'Acme' => __( 'Acme', 'ts-charity' ),
        'Anton' => __( 'Anton', 'ts-charity' ),
        'Architects Daughter' => __( 'Architects Daughter', 'ts-charity' ),
        'Arimo' => __( 'Arimo', 'ts-charity' ),
        'Arsenal' => __( 'Arsenal', 'ts-charity' ),
        'Arvo' => __( 'Arvo', 'ts-charity' ),
        'Alegreya' => __( 'Alegreya', 'ts-charity' ),
        'Alfa Slab One' => __( 'Alfa Slab One', 'ts-charity' ),
        'Averia Serif Libre' => __( 'Averia Serif Libre', 'ts-charity' ),
        'Bangers' => __( 'Bangers', 'ts-charity' ),
        'Boogaloo' => __( 'Boogaloo', 'ts-charity' ),
        'Bad Script' => __( 'Bad Script', 'ts-charity' ),
        'Bitter' => __( 'Bitter', 'ts-charity' ),
        'Bree Serif' => __( 'Bree Serif', 'ts-charity' ),
        'BenchNine' => __( 'BenchNine', 'ts-charity' ),
        'Cabin' => __( 'Cabin', 'ts-charity' ),
        'Cardo' => __( 'Cardo', 'ts-charity' ),
        'Courgette' => __( 'Courgette', 'ts-charity' ),
        'Cherry Swash' => __( 'Cherry Swash', 'ts-charity' ),
        'Cormorant Garamond' => __( 'Cormorant Garamond', 'ts-charity' ),
        'Crimson Text' => __( 'Crimson Text', 'ts-charity' ),
        'Cuprum' => __( 'Cuprum', 'ts-charity' ),
        'Cookie' => __( 'Cookie', 'ts-charity' ),
        'Chewy' => __( 'Chewy', 'ts-charity' ),
        'Days One' => __( 'Days One', 'ts-charity' ),
        'Dosis' => __( 'Dosis', 'ts-charity' ),
        'Droid Sans' => __( 'Droid Sans', 'ts-charity' ),
        'Economica' => __( 'Economica', 'ts-charity' ),
        'Fredoka One' => __( 'Fredoka One', 'ts-charity' ),
        'Fjalla One' => __( 'Fjalla One', 'ts-charity' ),
        'Francois One' => __( 'Francois One', 'ts-charity' ),
        'Frank Ruhl Libre' => __( 'Frank Ruhl Libre', 'ts-charity' ),
        'Gloria Hallelujah' => __( 'Gloria Hallelujah', 'ts-charity' ),
        'Great Vibes' => __( 'Great Vibes', 'ts-charity' ),
        'Handlee' => __( 'Handlee', 'ts-charity' ),
        'Hammersmith One' => __( 'Hammersmith One', 'ts-charity' ),
        'Inconsolata' => __( 'Inconsolata', 'ts-charity' ),
        'Indie Flower' => __( 'Indie Flower', 'ts-charity' ),
        'IM Fell English SC' => __( 'IM Fell English SC', 'ts-charity' ),
        'Julius Sans One' => __( 'Julius Sans One', 'ts-charity' ),
        'Josefin Slab' => __( 'Josefin Slab', 'ts-charity' ),
        'Josefin Sans' => __( 'Josefin Sans', 'ts-charity' ),
        'Kanit' => __( 'Kanit', 'ts-charity' ),
        'Lobster' => __( 'Lobster', 'ts-charity' ),
        'Lato' => __( 'Lato', 'ts-charity' ),
        'Lora' => __( 'Lora', 'ts-charity' ),
        'Libre Baskerville' => __( 'Libre Baskerville', 'ts-charity' ),
        'Lobster Two' => __( 'Lobster Two', 'ts-charity' ),
        'Merriweather' => __( 'Merriweather', 'ts-charity' ),
        'Monda' => __( 'Monda', 'ts-charity' ),
        'Montserrat' => __( 'Montserrat', 'ts-charity' ),
        'Muli' => __( 'Muli', 'ts-charity' ),
        'Marck Script' => __( 'Marck Script', 'ts-charity' ),
        'Noto Serif' => __( 'Noto Serif', 'ts-charity' ),
        'Open Sans' => __( 'Open Sans', 'ts-charity' ),
        'Overpass' => __( 'Overpass', 'ts-charity' ),
        'Overpass Mono' => __( 'Overpass Mono', 'ts-charity' ),
        'Oxygen' => __( 'Oxygen', 'ts-charity' ),
        'Orbitron' => __( 'Orbitron', 'ts-charity' ),
        'Patua One' => __( 'Patua One', 'ts-charity' ),
        'Pacifico' => __( 'Pacifico', 'ts-charity' ),
        'Padauk' => __( 'Padauk', 'ts-charity' ),
        'Playball' => __( 'Playball', 'ts-charity' ),
        'Playfair Display' => __( 'Playfair Display', 'ts-charity' ),
        'PT Sans' => __( 'PT Sans', 'ts-charity' ),
        'Philosopher' => __( 'Philosopher', 'ts-charity' ),
        'Permanent Marker' => __( 'Permanent Marker', 'ts-charity' ),
        'Poiret One' => __( 'Poiret One', 'ts-charity' ),
        'Quicksand' => __( 'Quicksand', 'ts-charity' ),
        'Quattrocento Sans' => __( 'Quattrocento Sans', 'ts-charity' ),
        'Raleway' => __( 'Raleway', 'ts-charity' ),
        'Rubik' => __( 'Rubik', 'ts-charity' ),
        'Rokkitt' => __( 'Rokkitt', 'ts-charity' ),
        'Russo One' => __( 'Russo One', 'ts-charity' ),
        'Righteous' => __( 'Righteous', 'ts-charity' ),
        'Slabo' => __( 'Slabo', 'ts-charity' ),
        'Source Sans Pro' => __( 'Source Sans Pro', 'ts-charity' ),
        'Shadows Into Light Two' => __( 'Shadows Into Light Two', 'ts-charity'),
        'Shadows Into Light' => __( 'Shadows Into Light', 'ts-charity' ),
        'Sacramento' => __( 'Sacramento', 'ts-charity' ),
        'Shrikhand' => __( 'Shrikhand', 'ts-charity' ),
        'Tangerine' => __( 'Tangerine', 'ts-charity' ),
        'Ubuntu' => __( 'Ubuntu', 'ts-charity' ),
        'VT323' => __( 'VT323', 'ts-charity' ),
        'Varela Round' => __( 'Varela Round', 'ts-charity' ),
        'Vampiro One' => __( 'Vampiro One', 'ts-charity' ),
        'Vollkorn' => __( 'Vollkorn', 'ts-charity' ),
        'Volkhov' => __( 'Volkhov', 'ts-charity' ),
        'Yanone Kaffeesatz' => __( 'Yanone Kaffeesatz', 'ts-charity' )
    );

	//Typography
	$wp_customize->add_section( 'ts_charity_typography', array(
    	'title'      => __( 'Typography', 'ts-charity' ),
		'priority'   => 30,
		'panel' => 'ts_charity_panel_id'
	) );
	
	// This is Paragraph Color picker setting
	$wp_customize->add_setting( 'ts_charity_paragraph_color', array(
		'default' => '',
		'sanitize_callback'	=> 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'ts_charity_paragraph_color', array(
		'label' => __('Paragraph Color', 'ts-charity'),
		'section' => 'ts_charity_typography',
		'settings' => 'ts_charity_paragraph_color',
	)));

	//This is Paragraph FontFamily picker setting
	$wp_customize->add_setting('ts_charity_paragraph_font_family',array(
	  'default' => '',
	  'capability' => 'edit_theme_options',
	  'sanitize_callback' => 'ts_charity_sanitize_choices'
	));
	$wp_customize->add_control(
	    'ts_charity_paragraph_font_family', array(
	    'section'  => 'ts_charity_typography',
	    'label'    => __( 'Paragraph Fonts','ts-charity'),
	    'type'     => 'select',
	    'choices'  => $font_array,
	));

	$wp_customize->add_setting('ts_charity_paragraph_font_size',array(
		'default'	=> '12px',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	
	$wp_customize->add_control('ts_charity_paragraph_font_size',array(
		'label'	=> __('Paragraph Font Size','ts-charity'),
		'section'	=> 'ts_charity_typography',
		'setting'	=> 'ts_charity_paragraph_font_size',
		'type'	=> 'text'
	));

	// This is "a" Tag Color picker setting
	$wp_customize->add_setting( 'ts_charity_atag_color', array(
		'default' => '',
		'sanitize_callback'	=> 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'ts_charity_atag_color', array(
		'label' => __('"a" Tag Color', 'ts-charity'),
		'section' => 'ts_charity_typography',
		'settings' => 'ts_charity_atag_color',
	)));

	//This is "a" Tag FontFamily picker setting
	$wp_customize->add_setting('ts_charity_atag_font_family',array(
	  'default' => '',
	  'capability' => 'edit_theme_options',
	  'sanitize_callback' => 'ts_charity_sanitize_choices'
	));
	$wp_customize->add_control(
	    'ts_charity_atag_font_family', array(
	    'section'  => 'ts_charity_typography',
	    'label'    => __( '"a" Tag Fonts','ts-charity'),
	    'type'     => 'select',
	    'choices'  => $font_array,
	));

	// This is "a" Tag Color picker setting
	$wp_customize->add_setting( 'ts_charity_li_color', array(
		'default' => '',
		'sanitize_callback'	=> 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'ts_charity_li_color', array(
		'label' => __('"li" Tag Color', 'ts-charity'),
		'section' => 'ts_charity_typography',
		'settings' => 'ts_charity_li_color',
	)));

	//This is "li" Tag FontFamily picker setting
	$wp_customize->add_setting('ts_charity_li_font_family',array(
	  'default' => '',
	  'capability' => 'edit_theme_options',
	  'sanitize_callback' => 'ts_charity_sanitize_choices'
	));
	$wp_customize->add_control(
	    'ts_charity_li_font_family', array(
	    'section'  => 'ts_charity_typography',
	    'label'    => __( '"li" Tag Fonts','ts-charity'),
	    'type'     => 'select',
	    'choices'  => $font_array,
	));

	// This is H1 Color picker setting
	$wp_customize->add_setting( 'ts_charity_h1_color', array(
		'default' => '',
		'sanitize_callback'	=> 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'ts_charity_h1_color', array(
		'label' => __('H1 Color', 'ts-charity'),
		'section' => 'ts_charity_typography',
		'settings' => 'ts_charity_h1_color',
	)));

	//This is H1 FontFamily picker setting
	$wp_customize->add_setting('ts_charity_h1_font_family',array(
	  'default' => '',
	  'capability' => 'edit_theme_options',
	  'sanitize_callback' => 'ts_charity_sanitize_choices'
	));
	$wp_customize->add_control(
	    'ts_charity_h1_font_family', array(
	    'section'  => 'ts_charity_typography',
	    'label'    => __( 'H1 Fonts','ts-charity'),
	    'type'     => 'select',
	    'choices'  => $font_array,
	));

	//This is H1 FontSize setting
	$wp_customize->add_setting('ts_charity_h1_font_size',array(
		'default'	=> '50px',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	
	$wp_customize->add_control('ts_charity_h1_font_size',array(
		'label'	=> __('H1 Font Size','ts-charity'),
		'section'	=> 'ts_charity_typography',
		'setting'	=> 'ts_charity_h1_font_size',
		'type'	=> 'text'
	));

	// This is H2 Color picker setting
	$wp_customize->add_setting( 'ts_charity_h2_color', array(
		'default' => '',
		'sanitize_callback'	=> 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'ts_charity_h2_color', array(
		'label' => __('h2 Color', 'ts-charity'),
		'section' => 'ts_charity_typography',
		'settings' => 'ts_charity_h2_color',
	)));

	//This is H2 FontFamily picker setting
	$wp_customize->add_setting('ts_charity_h2_font_family',array(
	  'default' => '',
	  'capability' => 'edit_theme_options',
	  'sanitize_callback' => 'ts_charity_sanitize_choices'
	));
	$wp_customize->add_control(
	    'ts_charity_h2_font_family', array(
	    'section'  => 'ts_charity_typography',
	    'label'    => __( 'h2 Fonts','ts-charity'),
	    'type'     => 'select',
	    'choices'  => $font_array,
	));

	//This is H2 FontSize setting
	$wp_customize->add_setting('ts_charity_h2_font_size',array(
		'default'	=> '45px',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	
	$wp_customize->add_control('ts_charity_h2_font_size',array(
		'label'	=> __('h2 Font Size','ts-charity'),
		'section'	=> 'ts_charity_typography',
		'setting'	=> 'ts_charity_h2_font_size',
		'type'	=> 'text'
	));

	// This is H3 Color picker setting
	$wp_customize->add_setting( 'ts_charity_h3_color', array(
		'default' => '',
		'sanitize_callback'	=> 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'ts_charity_h3_color', array(
		'label' => __('h3 Color', 'ts-charity'),
		'section' => 'ts_charity_typography',
		'settings' => 'ts_charity_h3_color',
	)));

	//This is H3 FontFamily picker setting
	$wp_customize->add_setting('ts_charity_h3_font_family',array(
	  'default' => '',
	  'capability' => 'edit_theme_options',
	  'sanitize_callback' => 'ts_charity_sanitize_choices'
	));
	$wp_customize->add_control(
	    'ts_charity_h3_font_family', array(
	    'section'  => 'ts_charity_typography',
	    'label'    => __( 'h3 Fonts','ts-charity'),
	    'type'     => 'select',
	    'choices'  => $font_array,
	));

	//This is H3 FontSize setting
	$wp_customize->add_setting('ts_charity_h3_font_size',array(
		'default'	=> '36px',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	
	$wp_customize->add_control('ts_charity_h3_font_size',array(
		'label'	=> __('h3 Font Size','ts-charity'),
		'section'	=> 'ts_charity_typography',
		'setting'	=> 'ts_charity_h3_font_size',
		'type'	=> 'text'
	));

	// This is H4 Color picker setting
	$wp_customize->add_setting( 'ts_charity_h4_color', array(
		'default' => '',
		'sanitize_callback'	=> 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'ts_charity_h4_color', array(
		'label' => __('h4 Color', 'ts-charity'),
		'section' => 'ts_charity_typography',
		'settings' => 'ts_charity_h4_color',
	)));

	//This is H4 FontFamily picker setting
	$wp_customize->add_setting('ts_charity_h4_font_family',array(
	  'default' => '',
	  'capability' => 'edit_theme_options',
	  'sanitize_callback' => 'ts_charity_sanitize_choices'
	));
	$wp_customize->add_control(
	    'ts_charity_h4_font_family', array(
	    'section'  => 'ts_charity_typography',
	    'label'    => __( 'h4 Fonts','ts-charity'),
	    'type'     => 'select',
	    'choices'  => $font_array,
	));

	//This is H4 FontSize setting
	$wp_customize->add_setting('ts_charity_h4_font_size',array(
		'default'	=> '30px',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	
	$wp_customize->add_control('ts_charity_h4_font_size',array(
		'label'	=> __('h4 Font Size','ts-charity'),
		'section'	=> 'ts_charity_typography',
		'setting'	=> 'ts_charity_h4_font_size',
		'type'	=> 'text'
	));

	// This is H5 Color picker setting
	$wp_customize->add_setting( 'ts_charity_h5_color', array(
		'default' => '',
		'sanitize_callback'	=> 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'ts_charity_h5_color', array(
		'label' => __('h5 Color', 'ts-charity'),
		'section' => 'ts_charity_typography',
		'settings' => 'ts_charity_h5_color',
	)));

	//This is H5 FontFamily picker setting
	$wp_customize->add_setting('ts_charity_h5_font_family',array(
	  'default' => '',
	  'capability' => 'edit_theme_options',
	  'sanitize_callback' => 'ts_charity_sanitize_choices'
	));
	$wp_customize->add_control(
	    'ts_charity_h5_font_family', array(
	    'section'  => 'ts_charity_typography',
	    'label'    => __( 'h5 Fonts','ts-charity'),
	    'type'     => 'select',
	    'choices'  => $font_array,
	));

	//This is H5 FontSize setting
	$wp_customize->add_setting('ts_charity_h5_font_size',array(
		'default'	=> '25px',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	
	$wp_customize->add_control('ts_charity_h5_font_size',array(
		'label'	=> __('h5 Font Size','ts-charity'),
		'section'	=> 'ts_charity_typography',
		'setting'	=> 'ts_charity_h5_font_size',
		'type'	=> 'text'
	));

	// This is H6 Color picker setting
	$wp_customize->add_setting( 'ts_charity_h6_color', array(
		'default' => '',
		'sanitize_callback'	=> 'sanitize_hex_color'
	));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'ts_charity_h6_color', array(
		'label' => __('h6 Color', 'ts-charity'),
		'section' => 'ts_charity_typography',
		'settings' => 'ts_charity_h6_color',
	)));

	//This is H6 FontFamily picker setting
	$wp_customize->add_setting('ts_charity_h6_font_family',array(
	  'default' => '',
	  'capability' => 'edit_theme_options',
	  'sanitize_callback' => 'ts_charity_sanitize_choices'
	));
	$wp_customize->add_control(
	    'ts_charity_h6_font_family', array(
	    'section'  => 'ts_charity_typography',
	    'label'    => __( 'h6 Fonts','ts-charity'),
	    'type'     => 'select',
	    'choices'  => $font_array,
	));

	//This is H6 FontSize setting
	$wp_customize->add_setting('ts_charity_h6_font_size',array(
		'default'	=> '18px',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	
	$wp_customize->add_control('ts_charity_h6_font_size',array(
		'label'	=> __('h6 Font Size','ts-charity'),
		'section'	=> 'ts_charity_typography',
		'setting'	=> 'ts_charity_h6_font_size',
		'type'	=> 'text'
	));

	//Top Bar
	$wp_customize->add_section('ts_charity_topbar_header',array(
		'title'	=> __('Top Bar Section','ts-charity'),
		'description'	=> __('Add Top Bar Content here','ts-charity'),
		'priority'	=> null,
		'panel' => 'ts_charity_panel_id',
	) );

	$wp_customize->add_setting('ts_charity_youtube_url',array(
		'default'	=> '',
		'sanitize_callback'	=> 'esc_url_raw'
	) );	
	$wp_customize->add_control('ts_charity_youtube_url',array(
		'label'	=> __('Add Youtube link','ts-charity'),
		'section'	=> 'ts_charity_topbar_header',
		'setting'	=> 'ts_charity_youtube_url',
		'type'		=> 'url'
	) );

	$wp_customize->add_setting('ts_charity_facebook_url',array(
		'default'	=> '',
		'sanitize_callback'	=> 'esc_url_raw'
	) );
	$wp_customize->add_control('ts_charity_facebook_url',array(
		'label'	=> __('Add Facebook link','ts-charity'),
		'section'	=> 'ts_charity_topbar_header',
		'setting'	=> 'ts_charity_facebook_url',
		'type'	=> 'url'
	) );

	$wp_customize->add_setting('ts_charity_twitter_url',array(
		'default'	=> '',
		'sanitize_callback'	=> 'esc_url_raw'
	) );	
	$wp_customize->add_control('ts_charity_twitter_url',array(
		'label'	=> __('Add Twitter link','ts-charity'),
		'section'	=> 'ts_charity_topbar_header',
		'setting'	=> 'ts_charity_twitter_url',
		'type'	=> 'url'
	) );

	$wp_customize->add_setting('ts_charity_rss_url',array(
		'default'	=> '',
		'sanitize_callback'	=> 'esc_url_raw'
	) );	
	$wp_customize->add_control('ts_charity_rss_url',array(
		'label'	=> __('Add RSS link','ts-charity'),
		'section'	=> 'ts_charity_topbar_header',
		'setting'	=> 'ts_charity_rss_url',
		'type'	=> 'url'
	) );

	$wp_customize->add_setting('ts_charity_insta_url',array(
		'default'	=> '',
		'sanitize_callback'	=> 'esc_url_raw'
	) );	
	$wp_customize->add_control('ts_charity_insta_url',array(
		'label'	=> __('Add Instagram link','ts-charity'),
		'section'	=> 'ts_charity_topbar_header',
		'setting'	=> 'ts_charity_insta_url',
		'type'	=> 'url'
	) );

	$wp_customize->add_setting('ts_charity_pint_url',array(
		'default'	=> '',
		'sanitize_callback'	=> 'esc_url_raw'
	) );	
	$wp_customize->add_control('ts_charity_pint_url',array(
		'label'	=> __('Add Pintrest link','ts-charity'),
		'section'	=> 'ts_charity_topbar_header',
		'setting'	=> 'ts_charity_pint_url',
		'type'	=> 'url'
	) );

	$wp_customize->add_setting('ts_charity_call',array(
		'default'	=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));	
	$wp_customize->add_control('ts_charity_call',array(
		'label'	=> __('Add Phone Number','ts-charity'),
		'section'	=> 'ts_charity_topbar_header',
		'setting'	=> 'ts_charity_call',
		'type'		=> 'text'
	));

	$wp_customize->add_setting('ts_charity_time',array(
		'default'	=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('ts_charity_time',array(
		'label'	=> __('Add Time','ts-charity'),
		'section'	=> 'ts_charity_topbar_header',
		'setting'	=> 'ts_charity_time',
		'type'		=> 'text'
	));

	$wp_customize->add_setting('ts_charity_email',array(
		'default'	=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('ts_charity_email',array(
		'label'	=> __('Add Email','ts-charity'),
		'section'	=> 'ts_charity_topbar_header',
		'setting'	=> 'ts_charity_email',
		'type'		=> 'text'
	));

	//home page slider
	$wp_customize->add_section( 'ts_charity_slidersettings' , array(
    	'title'      => __( 'Slider Settings', 'ts-charity' ),
		'priority'   => null,
		'panel' => 'ts_charity_panel_id'
	) );

	for ( $count = 1; $count <= 4; $count++ ) {

		// Add color scheme setting and control.
		$wp_customize->add_setting( 'ts_charity_slidersettings_page' . $count, array(
			'default'           => '',
			'sanitize_callback' => 'absint'
		) );

		$wp_customize->add_control( 'ts_charity_slidersettings_page' . $count, array(
			'label'    => __( 'Select Slide Image Page', 'ts-charity' ),
			'section'  => 'ts_charity_slidersettings',
			'type'     => 'dropdown-pages'
		) );
	}

	//Our Causes
	$wp_customize->add_section('ts_charity_causes_section',array(
		'title'	=> __('Our Causes','ts-charity'),
		'description'	=> '',
		'priority'	=> null,
		'panel' => 'ts_charity_panel_id',
	));
	
	$wp_customize->add_setting('ts_charity_title',array(
		'default'	=> '',
		'sanitize_callback'	=> 'sanitize_text_field',
	));
	$wp_customize->add_control('ts_charity_title',array(
		'label'	=> __('Title','ts-charity'),
		'section'	=> 'ts_charity_causes_section',
		'type'	=> 'text'
	));

	$categories = get_categories();
	$cats = array();
	$i = 0;
	foreach($categories as $category){
	if($i==0){
	$default = $category->slug;
	$i++;
	}
	$cats[$category->slug] = $category->name;
	}

	$wp_customize->add_setting('ts_charity_causes_category',array(
		'default'	=> 'select',
		'sanitize_callback' => 'sanitize_text_field',
	));
	$wp_customize->add_control('ts_charity_causes_category',array(
		'type'    => 'select',
		'choices' => $cats,
		'label' => __('Select Category to display Latest Post','ts-charity'),
		'section' => 'ts_charity_causes_section',
	));

	//footer
	$wp_customize->add_section('ts_charity_footer_section',array(
		'title'	=> __('Footer Text','ts-charity'),
		'description'	=> __('Add some text for footer like copyright etc.','ts-charity'),
		'priority'	=> null,
		'panel' => 'ts_charity_panel_id',
	));
	
	$wp_customize->add_setting('ts_charity_footer_copy',array(
		'default'	=> '',
		'sanitize_callback'	=> 'sanitize_text_field',
	));	
	$wp_customize->add_control('ts_charity_footer_copy',array(
		'label'	=> __('Copyright Text','ts-charity'),
		'section'	=> 'ts_charity_footer_section',
		'type'		=> 'text'
	));
}
add_action( 'customize_register', 'ts_charity_customize_register' );	


/**
 * Singleton class for handling the theme's customizer integration.
 *
 * @since  1.0.0
 * @access public
 */
final class TS_Charity_Customize {

	/**
	 * Returns the instance.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return object
	 */
	public static function get_instance() {

		static $instance = null;

		if ( is_null( $instance ) ) {
			$instance = new self;
			$instance->setup_actions();
		}

		return $instance;
	}

	/**
	 * Constructor method.
	 *
	 * @since  1.0.0
	 * @access private
	 * @return void
	 */
	private function __construct() {}

	/**
	 * Sets up initial actions.
	 *
	 * @since  1.0.0
	 * @access private
	 * @return void
	 */
	private function setup_actions() {

		// Register panels, sections, settings, controls, and partials.
		add_action( 'customize_register', array( $this, 'sections' ) );

		// Register scripts and styles for the controls.
		add_action( 'customize_controls_enqueue_scripts', array( $this, 'enqueue_control_scripts' ), 0 );
	}

	/**
	 * Sets up the customizer sections.
	 *
	 * @since  1.0.0
	 * @access public
	 * @param  object  $manager
	 * @return void
	 */
	public function sections( $manager ) {

		// Load custom sections.
		load_template( trailingslashit( get_template_directory() ) . '/inc/section-pro.php' );

		// Register custom section types.
		$manager->register_section_type( 'TS_Charity_Customize_Section_Pro' );

		// Register sections.
		$manager->add_section(
			new TS_Charity_Customize_Section_Pro(
				$manager,
				'example_1',
				array(
					'priority'   => 9,
					'title'    => esc_html__( 'Charity Pro Theme', 'ts-charity' ),
					'pro_text' => esc_html__( 'Go Pro',         'ts-charity' ),
					'pro_url'  => esc_url('https://www.themeshopy.com/themes/premium-charity-wordpress-theme/')
				)
			)
		);
	}

	/**
	 * Loads theme customizer CSS.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return void
	 */
	public function enqueue_control_scripts() {

		wp_enqueue_script( 'ts-charity-customize-controls', trailingslashit( get_template_directory_uri() ) . '/js/customize-controls.js', array( 'customize-controls' ) );

		wp_enqueue_style( 'ts-charity-customize-controls', trailingslashit( get_template_directory_uri() ) . '/css/customize-controls.css' );
	}
}

// Doing this customizer thang!
TS_Charity_Customize::get_instance();