=== Advance Automobile WordPress Theme ===
Contributors: Themeshopy
Tags:left-sidebar, right-sidebar, one-column, two-columns, grid-layout, custom-colors, custom-background, custom-logo, custom-menu, custom-header, editor-style, featured-images, footer-widgets, full-width-template, theme-options, translation-ready, rtl-language-support, threaded-comments, blog, e-commerce, portfolio
Requires at least: 4.3
Tested up to: 4.9.8
Stable tag: 0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Advance Automobile is a stylish, versatile, modern and resourceful automobile WordPress theme for car showroom, automobile garage, second hand car selling company, car dealership, rental cars, mechanic, car repairing centre, motorbike showroom, bike garage, cab service and other such websites and businesses.

== Description ==

Advance Automobile is a stylish, versatile, modern and resourceful automobile WordPress theme for car showroom, automobile garage, second hand car selling company, car dealership, rental cars, mechanic, car repairing centre, motorbike showroom, bike garage, cab service and other such websites and businesses. It gives perfect skin for automotive sector websites whether it is a blog, portfolio or any other website. It is a customizable theme which can perfectly fit your imagination with its easily changeable elements. It has smart use of call to action (CTA) buttons and a welcoming homepage slider which can be full screen, full width or boxed. This automobile WordPress theme has 100% fluid layout and loads seamlessly on all browsing platforms. It can be translated to many other languages; supports RTL writing as well. It is packed with social media icons to easily promote your services and SEO is well taken care. This automobile theme has super smooth navigation with sliders and parallax scrolling. The thoroughly explained documentation will help you install, configure and make small changes to the theme.

== Changelog ==

= 0.1 =
* Initial version Released.

== Resources ==

Advance Automobile WordPress Theme, Copyright 2018 Themeshopy
Advance Automobile is distributed under the terms of the GNU GPL

Advance Automobile WordPress Theme is derived from Twenty Sixteen WordPress Theme, Copyright 2014-2015 WordPress.org
Twenty Sixteen is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see .

Theme is Built using the following resource bundles.

1	CSS bootstrap.css
    -- Copyright 2011-2018 The Bootstrap Authors
    -- https://github.com/twbs/bootstrap/blob/master/LICENSE
    
2	JS bootstrap.js
    -- Copyright 2011-2018 The Bootstrap Authors (https://github.com/twbs/bootstrap/graphs/contributors)
    -- https://github.com/twbs/bootstrap/blob/master/LICENSE

3	Free to use and abuse under the MIT license.
	-- http://www.opensource.org/licenses/mit-license.php
	-- font-awesome.css and fonts folder
	Font Awesome 5.0.0 by @davegandy - http://fontawesome.io - @fontawesome
 	-- License - http://fontawesome.io/license (Font: SIL OFL 1.1, CSS: MIT License)

4	Customizer Pro
	Source: https://github.com/justintadlock/trt-customizer-pro

5   Images used from pixabay.

	Pixabay Images
	License: CC0 1.0 Universal (CC0 1.0)
	Source:	https://pixabay.com/en/service/terms/

	Slider image, copyright elljay
	License: CC0 1.0 Universal (CC0 1.0)
	Source: https://pixabay.com/en/gas-station-vintage-classic-cars-1130664/

	Service image, copyright DokaRyan
	License: CC0 1.0 Universal (CC0 1.0)
	Source: https://pixabay.com/en/auto-repair-oil-change-oil-auto-3691962/

6   SmoothScroll
	Sources: http://www.smoothscroll.net/
	License: Licensed under the terms of the MIT license.\

7   Owl Carousel
 	Sources: https://github.com/OwlCarousel2/OwlCarousel2